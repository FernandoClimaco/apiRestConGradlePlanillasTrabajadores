package com.sv.planilla;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestConGradlePlanillasTrabajadoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
