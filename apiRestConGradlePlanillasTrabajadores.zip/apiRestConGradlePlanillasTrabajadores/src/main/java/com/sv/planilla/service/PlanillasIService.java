package com.sv.planilla.service;

import com.sv.planilla.modelo.Planillas;

public interface PlanillasIService {

	
	//METODOS CRUD:
	
	public void guardarPlanilla(Planillas planilla);
	
}
