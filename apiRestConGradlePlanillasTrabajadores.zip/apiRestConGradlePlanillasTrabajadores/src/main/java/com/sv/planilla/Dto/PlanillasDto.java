package com.sv.planilla.Dto;

import java.io.Serializable;

import javax.persistence.Column;

public class PlanillasDto implements Serializable {
 
	private static final long serialVersionUID = 1L;
	
	
	
	//VARIABLES:
    private int id;
	 
	private String nombre;
 
	private String apellidos;
	 
	private Double salario;
	
	
	 
	

	//GET Y SET:

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}

	
	
	
	

}
