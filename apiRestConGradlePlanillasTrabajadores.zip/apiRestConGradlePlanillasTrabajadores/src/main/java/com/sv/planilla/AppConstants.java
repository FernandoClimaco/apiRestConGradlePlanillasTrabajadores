package com.sv.planilla;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

 
@Configuration
@ConfigurationProperties(prefix="")
public class AppConstants {
	
	//1. variables estaticas y constante:
	private final String mensaje = "Soy full stack java developer";
	
	
	//Traidos desde mi archivo: application.properties.
	public static final String parametro = "%s";
	public static final String codigoErrorConflicto ="codigo.error.conflicto";
	public static final String mensajeErrorNoEncontrado = "codigo.error.noEncontrado";
	public static final String codigoErrorConflictoGuardar="mensaje.error.conflicto.guardar";
	public static final String mensajeErrorConflictoEditar = "mensaje.error.conflicto.editar";
	public static final String mensajeErrorConflictoEliminar = "mensaje.error.conflicto.eliminar";
	public static final String mensajeErrorConflictoNoEncontrado = "mensaje.error.conflicto.NoEncontrado";
	 
	 
	// Para mi services:
	public static final String codigoError="409";
	public static final String mensajeError="Error en la capa Services";
	public static final String codigoNoEncontrado="404"; 
	public static final String mensajeNoEncontrado="Error en la capa Services, Estos datos no existen!!";
	 
	
	
	

}
