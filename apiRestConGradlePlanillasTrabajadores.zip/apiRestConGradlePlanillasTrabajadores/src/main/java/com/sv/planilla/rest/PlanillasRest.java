package com.sv.planilla.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sv.planilla.Dto.PlanillasDto;
import com.sv.planilla.service.PlanillasService;
import com.sv.planilla.util.CustomException;
import com.sv.planilla.util.RestResponse;

 

@RestController
@RequestMapping("/planillas/")
public class PlanillasRest {
	
	
	@Autowired
	PlanillasService planillasService;
	
	@Autowired
	RestResponse restResponse;
	
	
	//METODOS CRUD:
	
	
	
	//1. Guardar
	@PostMapping("guardarPlanilla/")
	public ResponseEntity<?> guardarPlanillitas(@RequestBody PlanillasDto planillasDto){
		
		ResponseEntity<?> respuesta = null;
		
		try {
			planillasService.guardar(planillasDto);
			respuesta = restResponse.createCustomizedResponse(null, 200, "0", "Success");
			
		}catch(CustomException a) {
			respuesta = restResponse.createCustomizedResponse(null, 409, a.getCod(), a.getMessage());
		}catch(Exception exc) {
			respuesta = restResponse.createCustomizedResponse(null, 409, "409" , "Error en el servicio");
		}
		
		return respuesta; 
	} // fin
	
	
	

}
