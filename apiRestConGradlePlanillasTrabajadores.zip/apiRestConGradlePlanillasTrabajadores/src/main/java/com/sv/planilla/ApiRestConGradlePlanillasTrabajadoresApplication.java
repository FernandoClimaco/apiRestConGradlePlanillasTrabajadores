package com.sv.planilla;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;



@SpringBootApplication
public class ApiRestConGradlePlanillasTrabajadoresApplication implements CommandLineRunner{
	
	 private static final Logger logger = LoggerFactory.getLogger(ApiRestConGradlePlanillasTrabajadoresApplication.class);
     
     
	  @Autowired
	  private Environment env;     // Inyectamos el con el fin de obtener las propiedades. Environment
	  
	  @Value(value = "${spring.datasource.url}")
	  String mensajeRapido;
	  @Value(value= "${miApiRestPesa}")
	  String miApiRestPesa;
	  
	  
	  @Autowired
	  AppConstants  variablesEnviroment;
	   
	  @Override
		public void run(String... args) throws Exception {
			 // logger.info("{}", env.getProperty("JAVA_HOME"));   // Aqu�, recuperamos la variable de entorno. JAVA_HOME
			  logger.info("{}" , env.getProperty("mensaje.error"));   //  obtener la propiedad. application.properties
			  logger.info("{}" , env.getProperty("miApiRestPesa"));
			  System.out.println("LANZANDO MENSAJE: " + mensajeRapido);
			  System.out.println("Informacion para almacenamiento: " + miApiRestPesa); 
			//  System.out.println("Mensaje instanciado de la clase Variables Enviroment" + variablesEnviroment.getMensaje());
		}
	  

	public static void main(String[] args) {
		SpringApplication.run(ApiRestConGradlePlanillasTrabajadoresApplication.class, args);
	}

}
