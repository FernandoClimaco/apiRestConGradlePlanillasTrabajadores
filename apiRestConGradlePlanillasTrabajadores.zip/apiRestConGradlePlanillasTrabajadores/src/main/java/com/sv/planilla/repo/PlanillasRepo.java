package com.sv.planilla.repo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.sv.planilla.AppConstants;
import com.sv.planilla.modelo.Planillas;
import com.sv.planilla.repository.PlanillasRepository;
import com.sv.planilla.service.PlanillasIService;
import com.sv.planilla.util.CustomException;
 


@Component
public class PlanillasRepo implements PlanillasIService {

	// validaciones de metodos, para saber si el error viene de la bd o del desarrollador.
	
		//Instanciando Logger
		private static final Logger logger=LoggerFactory.getLogger(PlanillasRepo.class);
		
		
		
	@Autowired
	PlanillasRepository planillasRepository;
	
	@Autowired
	private Environment env; // Inyectamos el con el fin de obtener las propiedades. Environment
	
	
	
	
	@Override
	public void guardarPlanilla(Planillas planilla) {
		try {
			planillasRepository.save(planilla);
		} 
		catch(Exception exc) {
			exc.printStackTrace();
			logger.error("Error en la base de datos"); 
			 throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
						env.getProperty(AppConstants.codigoErrorConflictoGuardar));
		}
		  
	}   //Fin del metodo guardar planilla.
	
	
	
	

}
