package com.sv.planilla.util;

public class CustomException extends RuntimeException {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	//VARIABLES:
	private final String cod;
	
	
	
	//CREACION DE 2 CONSTRUCTORES:
	
	public CustomException(String codigo, String mensaje) {
		super(mensaje);
		this.cod = codigo;
	} 
	
	
	public CustomException(String mensaje) {
		super(mensaje);
		this.cod= "";
	}


	
	//GET:
	public String getCod() {
		return cod;
	}
	
	
	
	
	
}
