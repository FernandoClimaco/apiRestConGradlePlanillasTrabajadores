package com.sv.planilla.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sv.planilla.AppConstants;
import com.sv.planilla.Dto.PlanillasDto;
import com.sv.planilla.modelo.Planillas;
import com.sv.planilla.repo.PlanillasRepo;
import com.sv.planilla.util.CustomException;

 
 



@Service
@Transactional
public class PlanillasService{

	
	    // Instanciando Logger:
		private static final Logger logger = LoggerFactory.getLogger(PlanillasService.class);

		
		// Inyectamos el con el fin de obtener las propiedades. Environment
		@Autowired
		private Environment env; 
		
	 
		@Autowired
		PlanillasRepo planillasRepo;

		
		 
		
		// METODOS CRUD
		
		//1. Guardar 
		 
		public void guardar(PlanillasDto planillaDto) {

			try {
				//setiar a la clase Planilla
				 Planillas p = new Planillas();
				 p.setId(planillaDto.getId());
				 p.setNombre(planillaDto.getNombre());
				 p.setApellidos(planillaDto.getApellidos());
				 p.setSalario(planillaDto.getSalario());
				 
				 // Validaciones:
				 if(p.getNombre().equals(" ") || p.getNombre().isEmpty()) {
					 throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
								env.getProperty(AppConstants.codigoErrorConflictoGuardar) + ", ingresar nombre");
				 }if (p.getApellidos().equals("") || p.getApellidos().isEmpty()) {
						throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
								env.getProperty(AppConstants.codigoErrorConflictoGuardar) + ", ingresar apellidos");
				 }
				 if (p.getSalario() < 0 ) {
						throw new CustomException(env.getProperty(AppConstants.codigoErrorConflicto),
								env.getProperty(AppConstants.codigoErrorConflictoGuardar) + ", El salario debe ser mayor a 0.00 ");
					}
				 
				 planillasRepo.guardarPlanilla(p);
				
			}catch(CustomException a) {
				throw a; 
			}catch(Exception e) {
				logger.error("Datos no guardados");
				throw new CustomException(env.getProperty(AppConstants.codigoError),
						env.getProperty(AppConstants.mensajeError));
			}

			
			
			
		}
		
		
		
		
		
}
